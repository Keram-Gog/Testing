using AV.FurnaceLoading.Model;

namespace ValidatorTests
{
    public class UnitTest1
    {
        //????????????
        [Fact]
        public void PositiveSchema()
        {
            Validator validator = new Validator();
            LoadSchema schema = new LoadSchema();
            Cassette cassett = new Cassette(10, 10);
            var result = validator.SchemaValidFor(schema, cassett);
            result.Should().BeTrue();

        }
    }
}