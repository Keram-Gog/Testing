﻿namespace AV.FurnaceLoading.Model;

/// <summary>
/// Координаты
/// </summary>
/// <param name="X"></param>
/// <param name="Y"></param>
public record Coordinate
{
    //Есть, скорее всего, смысл считать тип COORDINATE из дробных чисел??
    public int X { get; set; }
    public int Y { get; set; }

    public Coordinate(int x, int y)
    {
        X = x;
        Y = y;
    }

    public bool NegativeCoordinates() => X < 0 || Y < 0;

    public static Coordinate operator +(Coordinate A, Coordinate B) => 
        new (A.X + B.X, A.Y + B.Y);

    public static Coordinate operator -(Coordinate A, Coordinate B) => 
        new (A.X - B.X, A.Y - B.Y);

    /// <summary>
    /// вращение
    /// </summary>
    /// <param name="angle"> угол</param>
    /// <returns></returns>
    public Coordinate Rotate(double angle) =>
        new((int)(X * Math.Cos(angle) - Y * Math.Sin(angle)), (int)(X * Math.Sin(angle) + Y * Math.Cos(angle)));

    public int Distance (Coordinate B) => 
        (int)(Math.Sqrt(Math.Pow((X - B.X),2) + Math.Pow(Y - B.Y, 2)));

    public Coordinate MinDistanceBetweenPointAndListPoint (List<Coordinate> listPoint)
    {
        List<int> distanceFromPointToCenter = new();
        foreach (Coordinate coord in listPoint)
        {
            distanceFromPointToCenter.Add(coord.Distance(this));
        }

        int idxMinDistance = distanceFromPointToCenter.IndexOf(distanceFromPointToCenter.Min());
        return listPoint[idxMinDistance];
    }
}
