﻿namespace AV.FurnaceLoading.Model;

/// <summary>
/// Кассета печи
/// </summary>
public class Cassette
{
    /// <summary>
    /// Высота
    /// </summary>
    public int Height { get; set; }

    /// <summary>
    /// Ширина
    /// </summary>
    public int Width { get; set; }

    public Cassette (int _width, int _height)
    {
        if (_width <= 0 || _height <= 0)
            throw new ArgumentException("Uncorrect coordinates");

        Height = _height;
        Width = _width;
    }
}
