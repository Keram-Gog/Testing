﻿namespace AV.FurnaceLoading.Model;

/// <summary>
/// Схема загрузки кассеты печи
/// </summary>
public class LoadSchema
{
    /// <summary>
    /// Места загрузки
    /// </summary>
    public IList<LoadPlace> Places { get; set; } = new List<LoadPlace>();
}

/// <summary>
/// Место загрузки
/// </summary>
public abstract class LoadPlace
{
    /// <summary>
    /// Координаты центра стержня
    /// </summary>
    public Coordinate Center { get; set; } = new Coordinate(1, 1);
}

/// <summary>
/// Место для загрузки круглого стержня
/// </summary>
public class CircleLoadPlace : LoadPlace
{
    /// <summary>
    /// Радиус
    /// </summary>
    public int Radius { get; set; }

    /// <summary>
    /// Диаметр
    /// </summary>
    public int Diameter { get; set; }

    public CircleLoadPlace(Coordinate _center, int _radius)
    {
        if (_center.NegativeCoordinates())
            throw new ArgumentException("Uncorrect center");
        Center = _center;

        if(_radius > _center.X || _radius > _center.Y || _radius <= 0)
            throw new ArgumentException("Uncorrect radius");
        Radius = _radius;
 
        Diameter = Radius * 2;
    }
}

/// <summary>
/// Варианты поворота прямоугольных стержней
/// </summary>
public enum RotationType
{
    None = 0,
    By45Degree = 45,
    By90Degree = 90,
    By135Degree = 135
}

/// <summary>
/// Место для прямоугльного стержня
/// </summary>
public class RectLoadPlace : LoadPlace
{
    /// <summary>
    /// Высота
    /// </summary>
    public int Height { get; set; }
    
    /// <summary>
    /// Ширина
    /// </summary>
    public int Width { get; set; }

    /// <summary>
    /// Координаты четырехугольника
    /// </summary
    public List<Coordinate> Coordinates { get; set; }

    /// <summary>
    /// Координаты четырехугольника после поворота
    /// </summary
    public List<Coordinate> RotatedCoordinates { get; set; }

    /// <summary>
    /// Поворот стержня
    /// </summary>
    public RotationType Rotation { get; set; }

    public RectLoadPlace(Coordinate _center, int _width, int _height, RotationType _rotation)
    {
        if (_center.NegativeCoordinates())
            throw new ArgumentException("Uncorrect center");
        Center = _center;

        if (_width <= 0 || _height <= 0 || (int)_height / 2 > _center.Y || (int)_width / 2 > _center.X)
            throw new ArgumentException("Uncorrect size");
        Width = _width;
        Height = _height;
        

        Rotation = _rotation;
        Coordinates = this.VertexCoordinatesWithSafetyDistance(0);

        List<Coordinate> rotatedCoordinatesTemp = CalcRotatedCoordinate(Coordinates);

        for (int i = 0; i < rotatedCoordinatesTemp.Count; i++)
        {
            if (rotatedCoordinatesTemp[i].NegativeCoordinates())
                throw new ArgumentException("Uncorrect coodrinates of vertexes after rotate");
        }
        RotatedCoordinates = rotatedCoordinatesTemp;
    }

    public List<Coordinate> VertexCoordinatesWithSafetyDistance (int safetyDistance)
    {
        int widthDiv2 = (int)Width / 2 + safetyDistance;
        int heightDiv2 = (int)Height / 2 + safetyDistance;
        List<Coordinate> coordinates = new()
        {
            new Coordinate(Center.X - widthDiv2, Center.Y - heightDiv2),  //Левая нижняя координата
            new Coordinate(Center.X - widthDiv2, Center.Y + heightDiv2),  //Левая верхняя координата
            new Coordinate(Center.X + widthDiv2, Center.Y + heightDiv2),  //Правая верхняя координата
            new Coordinate(Center.X + widthDiv2, Center.Y - heightDiv2)   //Правая нижняя координата
        };

        return coordinates;
    }

    public List<Coordinate> CalcRotatedCoordinate(List<Coordinate> noneRotation)
    {
        double angleRadian = ((int)Rotation) * Math.PI / 180;

        //Определяем начальные координаты четырехугольника ДО поворота
        List<Coordinate> coordinates = noneRotation;

        if ((int)Rotation != 0)                                                 //Если четырехугольник имеет хоть какой-то угол, то ...
        {
            for (int i = 0; i < coordinates.Count; i++)
            {
                coordinates[i] = coordinates[i] - Center;                       //Точку, относительно которой переворачиваем (центр), обозначаем, как начало координат. плоскости
                coordinates[i] = coordinates[i].Rotate(angleRadian);            //Считаем координату после переворота на заданный угол
                coordinates[i] = coordinates[i] + Center;                       //Снова сдвигаем координату на прежнее место
            }
        }

        return coordinates;
    }
}
