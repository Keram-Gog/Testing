﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AV.FurnaceLoading.Model.BaseModel;

public record Vector
{
    public int OffX { get; set; }
    public int OffY { get; set; }

    public Vector(Coordinate _start, Coordinate _end)
    {
        OffX = _end.X - _start.X;
        OffY = _end.Y - _start.Y;
    }


    public int ScalarProduct(Vector B) =>
        OffX * B.OffX + OffY * B.OffY;
}
