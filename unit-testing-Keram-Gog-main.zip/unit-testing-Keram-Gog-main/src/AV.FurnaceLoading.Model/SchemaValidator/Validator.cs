﻿using AV.FurnaceLoading.Model.BaseModel;

namespace AV.FurnaceLoading.Model;


public class Validator : ISchemaValidator
{
    public bool SchemaValidFor(LoadSchema schema, Cassette cassette)
    {
        for(int i = 1; i <= schema.Places.Count; i++)
        {
            List<LoadPlace> otherPlaces = schema.Places.ToList().GetRange(i, schema.Places.Count - i);
            if (!ValidPartOfSchema(schema.Places[i - 1], cassette, otherPlaces))
                return false;
        }

        return true;
    }

    public static bool ValidPartOfSchema(LoadPlace place, Cassette cassette, List<LoadPlace> otherPlaces)
    {
        if (!(ValidDistanceBetweenPlaceAndWalls(place, cassette)))
            return false;

        for (int i = 0; i < otherPlaces.Count; i++)
        {
            if(!ValidDistanceBetweenPlaces(place, otherPlaces[i]))
                return false;
        }

        return true;
    }

    public static bool ValidDistanceBetweenPlaceAndWalls(LoadPlace place, Cassette cassette) => place switch
    {
        CircleLoadPlace circlePlace => CircalLoadPlaceValidForWalls(circlePlace, cassette),
        RectLoadPlace rectPlace => RectlLoadPlaceValidForWalls(rectPlace, cassette),
        _ => throw new NotImplementedException()
    };

    public static bool ValidDistanceBetweenPlaces(LoadPlace A, LoadPlace B) => A switch
    {
        CircleLoadPlace circlePlaceA => B switch
        {
            CircleLoadPlace circlePlaceB => ValidDistanceBetweenPlacesCircleAndCircle(circlePlaceA, circlePlaceB),
            RectLoadPlace rectLoadPlaceB => ValidDistanceBetweenPlacesRectAndCircle(circlePlaceA, rectLoadPlaceB),
            _ => throw new NotImplementedException()
        },

        RectLoadPlace rectLoadPlaceA => B switch
        {
            CircleLoadPlace circleLoadPlaceB => ValidDistanceBetweenPlacesRectAndCircle(circleLoadPlaceB, rectLoadPlaceA),
            RectLoadPlace rectLoadPlaceB => ValidDistanceBetweenPlacesRectAndRect(rectLoadPlaceA, rectLoadPlaceB),
            _ => throw new NotImplementedException()
        },
        _ => throw new NotImplementedException()
    };

    public static bool ValidDistanceBetweenPlacesRectAndRect(RectLoadPlace A, RectLoadPlace B)
    {
        int safetyDistance = Math.Max(SafetyParameters.SafeDistanceBetweenPlaces(A), SafetyParameters.SafeDistanceBetweenPlaces(B));
        List<Coordinate> vertexCoordinatesOfA = A.VertexCoordinatesWithSafetyDistance(safetyDistance);
        vertexCoordinatesOfA = A.CalcRotatedCoordinate(vertexCoordinatesOfA);
        List<Coordinate> vertexCoordinatesOfB = B.RotatedCoordinates;


        //Сортируем по X для прямоугольника А
        List<Coordinate> sortAX = vertexCoordinatesOfA.OrderBy(x => x.X).ToList();
        //Сортируем по Y для прямоугольника А
        List<Coordinate> sortAY = vertexCoordinatesOfA.OrderBy(x => x.Y).ToList();

        //Сортируем по X для прямоугольника В
        List<Coordinate> sortBX = vertexCoordinatesOfB.OrderBy(x => x.X).ToList();
        //Сортируем по Y для прямоугольника В
        List<Coordinate> sortBY = vertexCoordinatesOfB.OrderBy(x => x.Y).ToList();

        bool f1 = sortAX.Last().X <= sortBX.First().X;
        bool f2 = sortAX.First().X >= sortBX.Last().X;
        bool f3 = sortAY.First().Y >= sortBY.Last().Y;
        bool f4 = sortAY.Last().Y <= sortBY.First().Y;

        return f1 || f2 || f3 || f4;
    }

    public static bool ValidDistanceBetweenPlacesCircleAndCircle(CircleLoadPlace A, CircleLoadPlace B)
    {
        int safetyDistance = Math.Max(SafetyParameters.SafeDistanceBetweenPlaces(A), SafetyParameters.SafeDistanceBetweenPlaces(B));
        int distanceBetweenCenters = A.Center.Distance(B.Center);

        return distanceBetweenCenters >= safetyDistance + A.Radius + B.Radius;
    }

    public static bool ValidDistanceBetweenPlacesRectAndCircle(CircleLoadPlace A, RectLoadPlace B)
    {
        int safetyDistance = Math.Max(SafetyParameters.SafeDistanceBetweenPlaces(A), SafetyParameters.SafeDistanceBetweenPlaces(B));
        int sumRadiusSafDistance = A.Radius + safetyDistance;

        //Проверка вложенности хоть какой-то точки черырехгранника в круг(с учетом безопасного расстояния) (круг пересек угол квадрата)
        Coordinate pointWithMinDistance = A.Center.MinDistanceBetweenPointAndListPoint(B.Coordinates);
        if (Math.Pow(pointWithMinDistance.X - A.Center.X, 2) + Math.Pow(pointWithMinDistance.Y - A.Center.Y, 2) < Math.Pow(sumRadiusSafDistance, 2))
            return false;

        //Найдем "крайние" точки круга
        List<Coordinate> circleCoordinates = new()
        {
            new Coordinate(A.Center.X - sumRadiusSafDistance, A.Center.Y),  //Самая левая координата круга
            new Coordinate(A.Center.X + sumRadiusSafDistance, A.Center.Y),  //Самая правая координата круга
            new Coordinate(A.Center.X, A.Center.Y + sumRadiusSafDistance),  //Самая верхняя координата круга
            new Coordinate(A.Center.X, A.Center.Y - sumRadiusSafDistance)   //Самая нижняя координата круга
        };

        //Проверка вложенности круга в четырехгранник (по центру круга), проверка пересечения стороны квадрата (по circleCoordinates)
        circleCoordinates.Add(A.Center);
        
        for(int i = 0; i < circleCoordinates.Count; i++)
        {
            int res = 0;
            for(int j = 0; j < B.RotatedCoordinates.Count; j++)
            {
                Vector vectA = new(B.RotatedCoordinates[j], B.RotatedCoordinates[(j + 1) % 4]);
                Vector vectB = new (B.RotatedCoordinates[j], circleCoordinates[i]);
                if (vectA.ScalarProduct(vectB) >= 0)
                    res++;
            }

            if (res == 0 || res == 4)
                return false;
        }

        return true;
    }

    public static bool RectlLoadPlaceValidForWalls(RectLoadPlace place, Cassette cassette)
    {
        List<Coordinate> coordinates = place.RotatedCoordinates;
        int safetyDistance = SafetyParameters.SafeDistanceToWalls(place);              //Расчет безопасного расстояния от стержня до стены

        //Сортируем по X
        List<Coordinate> sortX = coordinates.OrderBy(x => x.X).ToList();
        //Сортируем по Y
        List<Coordinate> sortY = coordinates.OrderBy(x => x.Y).ToList();

        return !(
                (sortX.First().X < safetyDistance || sortX.Last().X > cassette.Width - safetyDistance)
                || (sortY.First().Y < safetyDistance || sortY.Last().Y > cassette.Height - safetyDistance)
            );
    }

    public static bool CircalLoadPlaceValidForWalls(CircleLoadPlace place, Cassette cassette)
    {
        int safetyDistance = SafetyParameters.SafeDistanceToWalls(place);
        return !(
                (place.Center.X + place.Radius > cassette.Width - safetyDistance || place.Center.X - place.Radius < safetyDistance)
                || (place.Center.Y + place.Radius > cassette.Height - safetyDistance || place.Center.Y - place.Radius < safetyDistance)
            );
    }




}

