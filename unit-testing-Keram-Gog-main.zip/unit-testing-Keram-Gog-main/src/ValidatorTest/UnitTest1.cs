using AV.FurnaceLoading.Model;
using FluentAssertions;


namespace ValidatorTest
{
    public class UnitTest1
    {
        [Fact]
        public void PositiveSchema()
        {
            Validator validator = new Validator();
            LoadSchema schema = new LoadSchema();
            Cassette cassett = new Cassette(10, 10);
            var result = validator.SchemaValidFor(schema, cassett);
            result.Should().BeTrue();
        }

        [Theory]
        [MemberData(nameof(TwoReactDataForTrueResult))]
        public void ValidDistanceBetweenPlacesRectAndRectTestTrueResult(RectLoadPlace A, RectLoadPlace B)
        {
            Assert.True(Validator.ValidDistanceBetweenPlacesRectAndRect(A, B));
        }
        public static IEnumerable<object[]> TwoReactDataForTrueResult()
        {
            yield return new object[] { new RectLoadPlace(new Coordinate(20, 20), 15,15, RotationType.None),
                new RectLoadPlace(new Coordinate(100, 100), 15, 15, RotationType.None) };
            yield return new object[] { new RectLoadPlace(new Coordinate(20, 20), 15,15, RotationType.None),
                new RectLoadPlace(new Coordinate(100, 100), 15, 15, RotationType.By45Degree) };
        }
        [Theory]
        [MemberData(nameof(TwoReactDataForFalseResult))]
        public void ValidDistanceBetweenPlacesRectAndRectTest(RectLoadPlace A, RectLoadPlace B)
        {
            Assert.False(Validator.ValidDistanceBetweenPlacesRectAndRect(A, B));
        }
        public static IEnumerable<object[]> TwoReactDataForFalseResult()
        {
            yield return new object[] { new RectLoadPlace(new Coordinate(10, 10), 15,15, RotationType.None),
                new RectLoadPlace(new Coordinate(44, 44), 15, 15, RotationType.None) };
            yield return new object[] { new RectLoadPlace(new Coordinate(21, 18), 30,30, RotationType.None),
                new RectLoadPlace(new Coordinate(50, 44), 15, 15, RotationType.None) };
            yield return new object[] { new RectLoadPlace(new Coordinate(10, 10), 15,15, 0),
                new RectLoadPlace(new Coordinate(25, 50), 15, 15, 0) };
            yield return new object[] { new RectLoadPlace(new Coordinate(10, 10), 15,15, 0),
                new RectLoadPlace(new Coordinate(32, 11), 15, 15, RotationType.By90Degree) };
        }


        [Theory]
        [MemberData(nameof(TestData))]
        public void Test(CircleLoadPlace place, Cassette cassette)
        {

            Assert.False(Validator.CircalLoadPlaceValidForWalls(place, cassette));
        }

        
        public static IEnumerable<object[]> TestData()
        {
            // ��� 4 �������� ������ ���� ����������� � ��������������� �����
            var cassette = new Cassette(28, 28);
            yield return new object[] { new CircleLoadPlace(new Coordinate(20, 20), 8), cassette };
            yield return new object[] { new CircleLoadPlace(new Coordinate(44, 12), 8), cassette };
            yield return new object[] { new CircleLoadPlace(new Coordinate(22, 14), 4), cassette };
            yield return new object[] { new CircleLoadPlace(new Coordinate(14, 6), 4), cassette };
        }

        [Fact]
        public void TestingRectlLoadPlaceValidForWalls1()
        {
            Assert.True(Validator.RectlLoadPlaceValidForWalls(new RectLoadPlace(new Coordinate(10, 10), 5, 5, RotationType.None),
                new Cassette(100 ,100)));
        }
        [Fact]
        public void TestingRectlLoadPlaceValidForWalls2()
        {
            Assert.True(Validator.RectlLoadPlaceValidForWalls(new RectLoadPlace(new Coordinate(15, 15), 5, 5, RotationType.None),
                new Cassette(45, 45)));
        }
        [Fact]
        public void TestingRectlLoadPlaceValidForWalls3()
        {
            Assert.False(Validator.RectlLoadPlaceValidForWalls(new RectLoadPlace(new Coordinate(10, 10), 25, 25, RotationType.By45Degree),
                new Cassette(20, 20)));
        }
        
        [Theory]
        [MemberData(nameof(TestData))]
        public void ValidDistanceBetweenPlaceAndWallsShouldReturnsTrue(LoadPlace place, Cassette cassette)
        {
            Assert.False(Validator.ValidDistanceBetweenPlaceAndWalls(place, cassette));
        }


        [Theory]
        [MemberData(nameof(TwoCircleData))]
        public void ValidDistanceBetweenPlacesCircleAndCircle_Test(CircleLoadPlace A, CircleLoadPlace B)
        {
            Assert.False(Validator.ValidDistanceBetweenPlacesCircleAndCircle(A, B));
        }

        [Theory]
        [MemberData(nameof(CircleAndRectData))]
        public void ValidDistanceBetweenPlacesRectAndCircle_Test(CircleLoadPlace A, RectLoadPlace B)
        {
            Assert.False(Validator.ValidDistanceBetweenPlacesRectAndCircle(A, B));
        }

        public static IEnumerable<object[]> TwoCircleData()
        {
            yield return new object[] { new CircleLoadPlace(new Coordinate(20, 20), 8), new CircleLoadPlace(new Coordinate(44, 12), 8) };
            yield return new object[] { new CircleLoadPlace(new Coordinate(44, 44), 8), new CircleLoadPlace(new Coordinate(12, 44), 8) };
            yield return new object[] { new CircleLoadPlace(new Coordinate(6, 14), 4), new CircleLoadPlace(new Coordinate(14, 22), 4) };
            yield return new object[] { new CircleLoadPlace(new Coordinate(22, 14), 4), new CircleLoadPlace(new Coordinate(14, 6), 4) };
        }

        public static IEnumerable<object[]> CircleAndRectData()
        {
            yield return new object[] { new CircleLoadPlace(new Coordinate(6, 14), 4), new RectLoadPlace(new Coordinate(20, 20), 15,15, RotationType.None)};
            yield return new object[] { new CircleLoadPlace(new Coordinate(20, 20), 8), new RectLoadPlace(new Coordinate(20, 20), 15,15, RotationType.None)};
        }
    }
}