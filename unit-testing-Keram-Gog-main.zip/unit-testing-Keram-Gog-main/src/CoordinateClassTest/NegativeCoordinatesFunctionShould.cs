using AV.FurnaceLoading.Model;
using FluentAssertions;

namespace CoordinateClassTest
{
    // � ������ ����� ������������ ����� ��� ������ Coordinate
    public class ConstructorCoordinateShould
    {
        [Theory]
        [InlineData(1, 2)]
        [InlineData(-1, 2)]
        [InlineData(1, -2)]
        [InlineData(-5, -5)]
        [InlineData(0, 2)]
        [InlineData(0, 0)]
        public void SaveAnyIntegersToX(int x, int y)
        {
            Coordinate coordinate = new Coordinate(x, y);
            Assert.Equal(x, coordinate.X);
        }

        [Theory]
        [InlineData(1, 2)]
        [InlineData(-1, 2)]
        [InlineData(1, -2)]
        [InlineData(-5, -5)]
        [InlineData(0, 2)]
        [InlineData(0, 0)]
        public void SaveAnyIntegersToY(int x, int y)
        {
            Coordinate coordinate = new Coordinate(x, y);
            Assert.Equal(y, coordinate.Y);
        }
    }
    public class NegativeCoordinatesFunctionShould
    {
        [Fact]
        public void ReturnFalseWhenParametersIs0And0()
        {
            Coordinate testObject = new Coordinate(0, 0);
            Assert.False(testObject.NegativeCoordinates());
        }
        [Fact]
        public void ReturnFalseWhenParametersIs10And0()
        {
            Coordinate testObject = new Coordinate(10, 0);
            Assert.False(testObject.NegativeCoordinates());
        }

        [Fact]
        public void ReturnFalseWhenParametersIs0And10()
        {
            Coordinate testObject = new Coordinate(0, 10);
            Assert.False(testObject.NegativeCoordinates());
        }

        [Fact]
        public void ReturnFalseWhenParametersIs10And10()
        {
            Coordinate testObject = new Coordinate(10, 10);
            Assert.Equal(false, testObject.NegativeCoordinates());
        }

        [Fact]
        public void ReturnTrueWhenParametersIsNegative8And10()
        {
            Coordinate testObject = new Coordinate(-8, 10);
            Assert.True(testObject.NegativeCoordinates());
        }

        [Fact]
        public void ReturnTrueWhenParametersIs8AndNegative10()
        {
            Coordinate testObject = new Coordinate(8, -10);
            Assert.True(testObject.NegativeCoordinates());
        }

        [Fact]
        public void ReturnTrueWhenParametersNegative5AndNegative5()
        {
            Coordinate testObject = new Coordinate(-5, -5);
            Assert.True(testObject.NegativeCoordinates());
        }
    }

    public class OperatorSumShould
    {
        [Theory]
        [MemberData(nameof (Data))]
        public void ReturnResultWhenAddAAndB(Coordinate A, Coordinate B, Coordinate Result)
        {
            Assert.Equal(Result, A + B);
        }
        public static IEnumerable<object[]> Data =>
            new List<Coordinate[]>
            {
                new Coordinate[]{new Coordinate(1,2), new Coordinate(1,2), new Coordinate(2,4)},
                new Coordinate[]{new Coordinate(0,0), new Coordinate(3,5), new Coordinate(3,5)},
                new Coordinate[]{new Coordinate(2,0), new Coordinate(1,2), new Coordinate(3,2)},
                new Coordinate[]{new Coordinate(0,45), new Coordinate(234,2343), new Coordinate(234,2388)}
            };
    }

    public class OperatorSubtractingShould
    {
        [Theory]
        [MemberData(nameof(Data))]
        public void ReturnResultWhenBSubstractingFromA(Coordinate A, Coordinate B, Coordinate Result)
        {
            Assert.Equal(Result, A - B);
        }
        public static IEnumerable<object[]> Data =>
            new List<Coordinate[]>
            {
                new Coordinate[]{new Coordinate(1,2), new Coordinate(1,2), new Coordinate(0,0)},
                new Coordinate[]{new Coordinate(10,10), new Coordinate(0,0), new Coordinate(10,10)},
                new Coordinate[]{new Coordinate(2,3), new Coordinate(2,2), new Coordinate(0,1)},
                new Coordinate[]{new Coordinate(234,2343), new Coordinate(0, 45), new Coordinate(234,2298)}
            };

    }


    public class RotateFunctionShould
    {
        [Theory]
        [MemberData(nameof(Data))]
        public void ReturnRotatedCoordinateWhenTheInitialCoordinateIsRotatedByAnAngleAlpha(Coordinate initialCoordinate, double alpha, Coordinate rotatedCoordinate)
        {
            Coordinate calculatedRotatedCoordinate = initialCoordinate.Rotate(alpha);
            Assert.Equal(rotatedCoordinate,calculatedRotatedCoordinate);
        }
        public static IEnumerable<object[]> Data =>
            new List<object[]>
            {
                new object[]{new Coordinate(5,3), 0, new Coordinate(5,3)},
                new object[]{new Coordinate(5, 3), 45 , new Coordinate(1,6)},
                new object[]{new Coordinate(5, 3), 90 , new Coordinate(-3,5)},
                new object[]{new Coordinate(4, 4), 135 , new Coordinate(-6,0)}
            };

    }

    public class DistanceFunctionShould
    {
        [Theory]
        [MemberData(nameof(Data))]
        public void ReturnDistanceFromStartCoordinateToEndCoordinate(Coordinate start, Coordinate end, int distance)
        {
            Assert.Equal(start.Distance(end), distance);
        }
        public static IEnumerable<object[]> Data =>
            new List<object[]>
            {
                new object[]{new Coordinate(5,3),new Coordinate(5,3), 0},
                new object[]{new Coordinate(5, 3),new Coordinate(1,6), 5},
                new object[]{new Coordinate(5, 3),new Coordinate(-3,3), 8},
                new object[]{new Coordinate(4, 4), new Coordinate(2,4), 2}
            };

    }

}