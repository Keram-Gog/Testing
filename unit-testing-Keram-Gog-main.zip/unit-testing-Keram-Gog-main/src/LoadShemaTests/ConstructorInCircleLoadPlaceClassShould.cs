using AV.FurnaceLoading.Model;
using System.Net.NetworkInformation;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace LoadShemaTests
{
    public class ConstructorInCircleLoadPlaceClassShould
    {
        [Theory]
        [MemberData(nameof(DataForReturnExeption_UncorrectCenter_))]
        public void ReturnExeption_UncorrectCenter_WhenCenterCoordinateIsNegative(Coordinate center, int radius)
        {
            //arrange
            //act
            Action act = () => new CircleLoadPlace(center, radius);
            //assert
            ArgumentException exception = Assert.Throws<ArgumentException>(act);
            //The thrown exception can be used for even more detailed assertions.
            Assert.Equal("Uncorrect center", exception.Message);
        }
        public static IEnumerable<object[]> DataForReturnExeption_UncorrectCenter_ =>
            new List<object[]>
            {
                new object[]{ new Coordinate(-8, 10), 5},
                new object[]{ new Coordinate(8, -10), 5},
                new object[]{ new Coordinate(-8, -10),5}
            };

        [Theory]
        [MemberData(nameof(DataForReturnExeption_UncorrectRadius_))]
        public void ReturnExeption_UncorrectRadius_WhenRadiusMoreThenCoordinatesOrIsNegative(Coordinate center, int radius)
        {
            //arrange
            //act
            Action act = () => new CircleLoadPlace(center, radius);
            //assert
            ArgumentException exception = Assert.Throws<ArgumentException>(act);
            //The thrown exception can be used for even more detailed assertions.
            Assert.Equal("Uncorrect radius", exception.Message);
        }
        public static IEnumerable<object[]> DataForReturnExeption_UncorrectRadius_ =>
            new List<object[]>
            {
                new object[]{ new Coordinate(5, 8), 9},
                new object[]{ new Coordinate(5, 8), 8},
                new object[]{ new Coordinate(5, 8), 7},
                new object[]{ new Coordinate(5, 8), 6},
                new object[]{ new Coordinate(5, 8),0},
                new object[]{ new Coordinate(5, 8),-3}
            };

        [Theory]
        [MemberData(nameof(DataForSuccessfullInitialized))]
        public void TheDataIsBeingInitialized_Radius_Successfully(Coordinate center, int radius)
        {
            CircleLoadPlace verifiable = new CircleLoadPlace(center, radius);
            Assert.Equal(radius, verifiable.Radius);
        }
        [Theory]
        [MemberData(nameof(DataForSuccessfullInitialized))]
        public void TheDataIsBeingInitialized_Diameter_Successfully(Coordinate center, int radius)
        {
            CircleLoadPlace verifiable = new CircleLoadPlace(center, radius);
            Assert.Equal(2 * radius, verifiable.Diameter);
        }
        [Theory]
        [MemberData(nameof(DataForSuccessfullInitialized))]
        public void TheDataIsBeingInitialized_Center_Successfully(Coordinate center, int radius)
        {
            CircleLoadPlace verifiable = new CircleLoadPlace(center, radius);
            Assert.Equal(center, verifiable.Center);
        }

        public static IEnumerable<object[]> DataForSuccessfullInitialized =>
            new List<object[]>
            {
                new object[]{ new Coordinate(5, 8), 4},
                new object[]{ new Coordinate(5, 8), 3},
                new object[]{ new Coordinate(5, 8), 2},
                new object[]{ new Coordinate(5, 8), 5}
            };



        
    }

}